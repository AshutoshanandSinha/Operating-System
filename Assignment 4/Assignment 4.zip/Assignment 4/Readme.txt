/* 
 * $Author: Ashutoshanand Sinha 
 * $Revision: 1.0
 * $Date: 2019/11/08  
 * Java Version: 8
 */

 Instructions:
==================================================================================
1. Please copy "PagingNFUAging.class" file into one folder.  
2. Run PagingNFUAging file by typing below command:
   
   java PagingNFUAging

Enter the frame size, when prompted.


Note: java Software Development Kit should be installed on the system.