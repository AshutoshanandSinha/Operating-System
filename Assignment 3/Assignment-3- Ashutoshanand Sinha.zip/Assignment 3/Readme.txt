/* 
 * $Author: Ashutoshanand Sinha 
 * $Revision: 1.0
 * $Date: 2019/10/25  
 * Java Version: 8
 */

 Instructions:
==================================================================================
1. Please copy "Banker.java" and "Client"  file into one folder.
2. Compile Banker.java file by typing below command in terminal(Ensure you're in same folder where you copied above java files):
    i. javac Banker.java 
  
3. Run Banker.java file by typing below command:
   
   java Banker.java


Note: java Software Development Kit should be installed on the system.