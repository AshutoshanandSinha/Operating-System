
public class Client {

    String name;

    public String getName() {
        return name;
    }

}
