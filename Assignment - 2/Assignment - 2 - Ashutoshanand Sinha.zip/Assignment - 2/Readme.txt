/* 
 * $Author: Ashutoshanand Sinha 
 * $Revision: 1.0
 * $Date: 2019/10/18  
 * Java Version: 8
 */

 Instructions:
==================================================================================
1. Please copy "Producer.java", "PnCMain.java" and "Consumer.java" file into one folder.
2. Compile PnCMain.java file by typing below command in terminal(Ensure you're in same folder where you copied above java files):
    i. javac PnCMain.java 
  
3. Run PnCMain.java file by typing below command:
   
   java PnCMain


Note: java Software Development Kit should be installed on the system.