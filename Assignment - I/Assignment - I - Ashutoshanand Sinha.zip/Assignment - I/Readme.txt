/* 
 * $Author: Ashutoshanand Sinha 
 * $Revision: 1.0
 * $Date: 2019/10/11  
 * Java Version: 8
 */

 Instructions:
==================================================================================
1. Please copy "SJFScheduling.java" and "Proc.java" file into one folder.
2. Compile both java file by typing below command in terminal(Ensure you're in same folder where you copied above java files):
    i. javac SJFScheduling.java 
    ii. javac Proc.java
3. Run SJFScheduling file by typing below command:
   
   java SJFScheduling


Note: java Software Development Kit should be installed on the system.